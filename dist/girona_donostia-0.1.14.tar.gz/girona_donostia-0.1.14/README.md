# Girona_Donostia

This is a source for a Python Library to study nonlinear optical propreties using Gaussian. 
So far, this library can create a variety of Gaussian Input Files, and analize the output files (.log and .fchk files)

Main Functionality is described on the wiki page.
https://github.com/Petru-Milev/Girona_Donostia/wiki

Author: Petru Milev
