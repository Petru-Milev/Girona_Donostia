import numpy as np
from itertools import product
import ast
import os
import copy 
import datetime as dt

from girona_donostia import functions_for_library
from girona_donostia import  objects_for_library
from girona_donostia.objects_for_library import *
from girona_donostia.functions_for_library import *
